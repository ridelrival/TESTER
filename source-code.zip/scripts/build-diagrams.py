"""Create original vector diagrams for the nine visual prediction questions."""
from pathlib import Path
from math import cos, sin, pi

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "assets" / "diagrams"
OUT.mkdir(parents=True, exist_ok=True)


def svg(name, body, width=640, height=360):
    source = f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height}" role="img" aria-label="{name}">
<rect width="{width}" height="{height}" fill="#ffffff"/>
<style>text{{font-family:Arial,sans-serif;fill:#243740}}.axis{{fill:none;stroke:#243740;stroke-width:2}}.thin{{fill:none;stroke:#536775;stroke-width:1.5}}.bold{{fill:none;stroke:#167458;stroke-width:4}}.fill{{fill:#dcefe8;stroke:#167458;stroke-width:2}}</style>
{body}
</svg>'''
    (OUT / f"{name}.svg").write_text(source, encoding="utf-8")


pareto_bars = [("寸法", 72), ("傷", 42), ("汚れ", 22), ("欠け", 12), ("その他", 5)]
body = '<text x="38" y="36" font-size="21" font-weight="bold">Defect count by category</text><path d="M70 70V294H590" class="axis"/>'
for index, (label, count) in enumerate(pareto_bars):
    x = 92 + index * 96
    body += f'<rect x="{x}" y="{284-count*2.7}" width="56" height="{count*2.7}" fill="{("#167458" if index == 0 else "#89bbad")}"/>'
    body += f'<text x="{x+28}" y="315" text-anchor="middle" font-size="16">{label}</text><text x="{x+28}" y="{274-count*2.7}" text-anchor="middle" font-size="16">{count}</text>'
svg("pareto", body)

points = [(92,266),(133,247),(170,236),(185,255),(210,215),(249,219),(274,191),(299,207),(331,178),(356,169),(382,179),(409,145),(443,126),(466,139),(498,113),(531,95),(549,107)]
body = '<text x="38" y="36" font-size="21" font-weight="bold">Scatter plot</text><path d="M70 65V300H595" class="axis"/>'
body += '<text x="580" y="325" font-size="17">X</text><text x="42" y="72" font-size="17">Y</text>'
body += ''.join(f'<circle cx="{x}" cy="{y}" r="6" fill="#167458"/>' for x,y in points)
svg("scatter-positive", body)

# The main scale is 10 px per millimetre: vernier zero sits at 20.25 mm.
# A 0.05 mm vernier division spans 0.95 mm; the fifth division coincides
# exactly with the 25 mm main-scale tick.
body = '<text x="28" y="36" font-size="21" font-weight="bold">Vernier caliper · 0.05 mm</text><rect x="48" y="72" width="545" height="85" rx="6" fill="#eff5f2" stroke="#536775" stroke-width="2"/>'
for mm in range(0,51):
    x = 65 + mm*10
    length = 35 if mm % 5 == 0 else 20 if mm % 2 == 0 else 12
    body += f'<path d="M{x} 157v-{length}" class="thin"/>'
    if mm % 5 == 0:
        body += f'<text x="{x}" y="111" text-anchor="middle" font-size="15">{mm}</text>'
body += '<rect x="241" y="163" width="245" height="108" rx="6" class="fill"/><text x="342" y="254" text-anchor="middle" font-size="17">0.05 mm scale</text>'
for tick in range(21):
    x = 267.5 + tick*9.5
    length = 44 if tick % 5 == 0 else 25
    stroke = '#c43f46' if tick == 5 else '#243740'
    body += f'<path d="M{x:g} 163v{length}" stroke="{stroke}" stroke-width="{3 if tick == 5 else 1.5}"/>'
    if tick % 5 == 0:
        body += f'<text x="{x:g}" y="{224 if tick != 5 else 226}" text-anchor="middle" font-size="15" fill="{stroke}">{tick}</text>'
body += '<path d="M267.5 66V284" stroke="#c43f46" stroke-width="2" stroke-dasharray="5 5"/><text x="274" y="302" font-size="15">0</text>'
svg("vernier-2025", body)

body = '<text x="38" y="37" font-size="21" font-weight="bold">Line types in a drawing</text><rect x="85" y="84" width="440" height="202" fill="none" stroke="#243740" stroke-width="4"/>'
body += '<path d="M145 111V258M465 111V258" stroke="#167458" stroke-width="3" stroke-dasharray="13 9"/>'
body += '<text x="50" y="185" font-size="24">A</text><path d="M67 178h22" class="thin"/><text x="540" y="185" font-size="24">B</text><path d="M525 178h-55" class="thin"/>'
svg("drawing-lines", body)

body = '<text x="34" y="36" font-size="21" font-weight="bold">Third-angle projection</text><rect x="235" y="176" width="160" height="113" class="fill"/><rect x="235" y="65" width="160" height="75" fill="#f6faf8" stroke="#243740" stroke-width="2"/>'
body += '<rect x="430" y="176" width="118" height="113" fill="#f6faf8" stroke="#243740" stroke-width="2"/><path d="M235 234h160M315 176v113M235 102h160M315 65v75M430 234h118" class="thin" stroke-dasharray="7 5"/>'
body += '<text x="315" y="319" text-anchor="middle" font-size="17">FRONT</text><text x="315" y="158" text-anchor="middle" font-size="17">?</text><text x="489" y="319" text-anchor="middle" font-size="17">SIDE</text>'
svg("third-angle", body)

body = '<defs><pattern id="h" width="12" height="12" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><path d="M0 0V12" stroke="#167458" stroke-width="3"/></pattern></defs>'
body += '<text x="34" y="36" font-size="21" font-weight="bold">Section view</text><path d="M115 88H525V278H115V88ZM248 145H392V222H248V145Z" fill="url(#h)" fill-rule="evenodd" stroke="#243740" stroke-width="3"/>'
body += '<path d="M320 63v240M85 183h470" stroke="#536775" stroke-dasharray="12 5 3 5"/>'
svg("section-hatch", body)

body = '<text x="38" y="35" font-size="21" font-weight="bold">Dimension and tolerance</text><rect x="125" y="155" width="385" height="110" fill="#e7f2ed" stroke="#243740" stroke-width="3"/>'
body += '<path d="M125 283v49M510 283v49M125 314H510" class="axis"/><path d="M125 314l12 -7v14zM510 314l-12 -7v14z" fill="#243740"/>'
body += '<rect x="243" y="283" width="140" height="61" fill="white"/><text x="260" y="326" font-size="27" font-weight="bold">32</text><text x="310" y="307" font-size="18">+0.12</text><text x="310" y="332" font-size="18">−0.24</text>'
svg("dimension-tolerance", body)

body = '<text x="34" y="35" font-size="21" font-weight="bold">Welding symbol</text><path d="M112 204H537" class="axis"/><path d="M112 204l-26 -12 26 -12z" fill="#243740"/><path d="M314 204v-80l87 80z" fill="none" stroke="#167458" stroke-width="5"/>'
body += '<path d="M395 204l-48 70h-93" class="thin"/><text x="122" y="275" font-size="17">reference line</text>'
svg("fillet-symbol", body)

body = '<text x="36" y="38" font-size="21" font-weight="bold">Power switch symbol</text><rect x="174" y="69" width="292" height="225" rx="20" fill="#eef4f0" stroke="#536775" stroke-width="3"/>'
body += '<circle cx="320" cy="182" r="79" fill="white" stroke="#167458" stroke-width="7"/><circle cx="320" cy="182" r="45" fill="none" stroke="#243740" stroke-width="9"/>'
svg("power-off", body)

body = '<text x="36" y="35" font-size="21" font-weight="bold">GHS hazard pictogram</text><path d="M320 58L510 181 320 304 130 181Z" fill="white" stroke="#d33b45" stroke-width="19"/>'
body += '<path d="M320 91C300 135 338 145 300 181C285 155 278 147 274 143C274 179 248 188 250 223C252 267 286 283 320 283C360 283 390 254 389 217C388 185 371 169 360 151C357 176 346 185 338 188C348 156 327 138 320 91Z" fill="#243740"/>'
body += '<path d="M323 187C316 208 291 220 295 246C298 264 311 271 326 270C347 269 355 250 350 235C346 222 333 211 323 187Z" fill="white"/>'
svg("ghs-flame", body)

body = '<text x="36" y="36" font-size="21" font-weight="bold">Measurement histogram</text><path d="M65 65V290H590" class="axis"/>'
for index, count in enumerate([2, 5, 10, 17, 24, 20, 12, 6, 3]):
    x = 85 + index * 53
    body += f'<rect x="{x}" y="{290-count*7}" width="50" height="{count*7}" fill="#81b9a7" stroke="white" stroke-width="2"/>'
body += '<path d="M475 55V292" stroke="#c43f46" stroke-width="3" stroke-dasharray="8 5"/><text x="485" y="73" font-size="17" fill="#c43f46">USL</text>'
svg("histogram-usl", body)

body = '<text x="34" y="35" font-size="21" font-weight="bold">Cause-and-effect diagram</text><path d="M88 184H515" class="axis"/><path d="M515 184l-22 -10v20z" fill="#243740"/><rect x="515" y="152" width="108" height="65" fill="#e7f2ed" stroke="#167458" stroke-width="2"/>'
body += '<text x="568" y="180" text-anchor="middle" font-size="15">寸法</text><text x="568" y="201" text-anchor="middle" font-size="15">ばらつき</text>'
for x1,y1,x2,y2,label,lx,ly in [(160,184,103,95,"工具摩耗",63,86),(282,184,225,95,"材料",204,86),(405,184,348,95,"測定",326,86),(220,184,163,269,"手順",135,291),(354,184,297,269,"環境",277,291)]:
    body += f'<path d="M{x1} {y1}L{x2} {y2}" class="thin"/><text x="{lx}" y="{ly}" font-size="16">{label}</text>'
svg("fishbone", body)

body = '<text x="35" y="35" font-size="21" font-weight="bold">Process control chart</text><path d="M80 55V298H593" class="axis"/>'
for label,y in [("UCL",100),("CL",183),("LCL",266)]:
    body += f'<path d="M80 {y}H584" stroke="{("#c43f46" if label != "CL" else "#6d8079")}" stroke-width="2" stroke-dasharray="8 5"/><text x="34" y="{y+5}" font-size="16">{label}</text>'
points = [(105,178),(150,164),(195,188),(240,174),(285,191),(330,159),(375,183),(420,172),(465,189),(510,72),(555,178)]
body += '<path d="' + ' '.join(('M' if i == 0 else 'L') + f'{x} {y}' for i,(x,y) in enumerate(points)) + '" fill="none" stroke="#167458" stroke-width="3"/>'
body += ''.join(f'<circle cx="{x}" cy="{y}" r="{7 if y < 100 else 5}" fill="{("#c43f46" if y < 100 else "#167458")}"/>' for x,y in points)
svg("control-chart", body)

body = '<text x="35" y="35" font-size="21" font-weight="bold">Stress–strain curve</text><path d="M75 55V295H580" class="axis"/>'
body += '<text x="16" y="65" font-size="16">Stress</text><text x="540" y="324" font-size="16">Strain</text><path d="M75 295L180 136C210 132 240 143 265 132C326 103 400 83 451 91C492 101 525 125 548 156" fill="none" stroke="#167458" stroke-width="4"/>'
body += '<circle cx="180" cy="136" r="7" fill="#c43f46"/><text x="163" y="119" font-size="21">Y</text><path d="M180 136V295" stroke="#c43f46" stroke-dasharray="6 5"/>'
svg("stress-strain", body)

body = '<text x="35" y="35" font-size="21" font-weight="bold">Micrometer scale · 0.01 mm/div</text><rect x="60" y="135" width="285" height="120" rx="5" fill="#eef5f2" stroke="#536775" stroke-width="2"/><path d="M60 194H570" class="axis"/>'
for mm in range(0,13):
    x = 74 + mm * 21
    body += f'<path d="M{x} 195V{168 if mm % 5 else 154}" class="thin"/>'
    if mm % 2 == 0:
        body += f'<text x="{x}" y="150" text-anchor="middle" font-size="14">{mm}</text>'
body += '<rect x="346" y="105" width="220" height="180" fill="#dfeee9" stroke="#167458" stroke-width="2"/>'
for number,y in [(35,232),(36,213),(37,194),(38,175),(39,156),(40,137)]:
    body += f'<path d="M346 {y}H{405 if number % 5 == 0 else 382}" stroke="#243740" stroke-width="2"/>'
    if number % 5 == 0:
        body += f'<text x="416" y="{y+6}" font-size="16">{number}</text>'
body += '<path d="M346 194H566" stroke="#c43f46" stroke-width="2" stroke-dasharray="6 5"/>'
svg("micrometer-1237", body)

body = '<text x="35" y="35" font-size="21" font-weight="bold">Dial indicator · 0.01 mm/div</text><circle cx="320" cy="186" r="127" fill="#f7faf8" stroke="#243740" stroke-width="3"/>'
for tick in range(100):
    angle = (-90 + tick * 3.6) * pi / 180
    r1 = 105 if tick % 10 == 0 else 114
    x1,y1 = 320 + r1*cos(angle),186 + r1*sin(angle)
    x2,y2 = 320 + 122*cos(angle),186 + 122*sin(angle)
    body += f'<path d="M{x1:.1f} {y1:.1f}L{x2:.1f} {y2:.1f}" stroke="#536775" stroke-width="{2 if tick % 10 == 0 else 1}"/>'
    if tick % 10 == 0:
        tx,ty = 320 + 87*cos(angle),186 + 87*sin(angle)
        body += f'<text x="{tx:.1f}" y="{ty+5:.1f}" text-anchor="middle" font-size="15">{tick}</text>'
angle = (-90 + 35 * 3.6) * pi / 180
body += f'<path d="M320 186L{320+92*cos(angle):.1f} {186+92*sin(angle):.1f}" stroke="#c43f46" stroke-width="4"/><circle cx="320" cy="186" r="8" fill="#c43f46"/>'
svg("dial-035", body)

body = '<text x="36" y="38" font-size="21" font-weight="bold">Power switch symbol</text><rect x="174" y="69" width="292" height="225" rx="20" fill="#eef4f0" stroke="#536775" stroke-width="3"/>'
body += '<circle cx="320" cy="182" r="79" fill="white" stroke="#167458" stroke-width="7"/><path d="M320 123V242" stroke="#243740" stroke-width="14" stroke-linecap="round"/>'
svg("power-on", body)

print(f"Created {len(list(OUT.glob('*.svg')))} diagrams in {OUT}")

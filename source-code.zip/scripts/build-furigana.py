"""Generate reviewed-starting-point ruby data for authored Japanese items.

Requires pykakasi 2.3.0. Inspect ambiguous polyphonic terms before release.
"""
from __future__ import annotations

from collections import Counter, defaultdict
import json
from pathlib import Path
import re

import pykakasi

ROOT = Path(__file__).resolve().parents[1]
KANJI = re.compile(r"[\u3400-\u9fff々〆ヶ﨑髙𠮷]")
CONVERTER = pykakasi.kakasi()


def parts_for(value: str):
    parts = []
    position = 0
    for token in CONVERTER.convert(value):
        base, reading = token["orig"], token["hira"]
        found = value.find(base, position)
        if found < 0:
            continue
        if found > position:
            parts.append([value[position:found], None])
        position = found + len(base)
        if KANJI.search(base):
            # Keep matching okurigana and symbols outside ruby.
            suffix = ""
            while base and reading and base[-1] == reading[-1] and not KANJI.search(base[-1]):
                suffix = base[-1] + suffix
                base, reading = base[:-1], reading[:-1]
            if suffix:
                if base and reading:
                    parts.append([base, reading])
                parts.append([suffix, None])
                continue
            parts.append([base, reading])
        else:
            parts.append([base, None])
    if position < len(value):
        parts.append([value[position:], None])
    assert "".join(base for base, _ in parts) == value, value
    return parts


def main():
    questions = json.loads((ROOT / "questions.json").read_text(encoding="utf-8"))
    source_strings = set()
    for q in questions:
        for field in ("section", "category", "question", "source", "explanation", "knowledgeUnit"):
            source_strings.add(q[field])
        source_strings.update(q["choices"])
    texts = {value: parts_for(value) for value in sorted(source_strings)}
    candidates = defaultdict(Counter)
    for parts in texts.values():
        for base, reading in parts:
            if reading:
                candidates[base][reading] += 1
    terms = {base: [[base, count.most_common(1)[0][0]]] for base, count in sorted(candidates.items())}
    ambiguous = {base: dict(count) for base, count in candidates.items() if len(count) > 1}
    (ROOT / "furigana.json").write_text(json.dumps({"texts": texts, "terms": terms}, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    image_readings = {"pareto.svg": {"width": 640, "height": 360, "labels": [
        [120 / 640, 303 / 360, "すんぽう", False],
        [216 / 640, 303 / 360, "きず", False],
        [312 / 640, 303 / 360, "よごれ", False],
        [408 / 640, 303 / 360, "かけ", False],
        [504 / 640, 303 / 360, "そのた", False],
    ]}}
    (ROOT / "image-furigana.json").write_text(json.dumps(image_readings, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({"strings": len(texts), "terms": len(terms), "ambiguousTerms": ambiguous}, ensure_ascii=False))


if __name__ == "__main__":
    main()

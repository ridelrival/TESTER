"""Build the independently authored TG2 prediction bank from UTF-8 pipe files.

Each item has an explicit stable ID. Options are shuffled reproducibly so the
source files can keep the defensible answer first without creating an answer
position pattern in the app. This script never downloads or changes GitHub.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import random

ROOT = Path(__file__).resolve().parents[1]
CHAPTERS = {
    2: "第2章 安全衛生",
    3: "第3章 品質管理",
    4: "第4章 検査",
    5: "第5章 測定",
    6: "第6章 製図",
    7: "第7章 機械の操作・管理",
    8: "第8章 金属材料、金属加工",
    9: "第9章 電気機器・成形・塗装・包装・アルミニウム加工",
}
EXPECTED_SUBSECTIONS = {2: 18, 3: 13, 4: 10, 5: 7, 6: 21, 7: 6, 8: 7, 9: 17}


def read_bank():
    questions = []
    groups = {}
    group_meta = {}
    translations = {}
    for lineno, raw in enumerate((ROOT / "content" / "explanations-id.txt").read_text(encoding="utf-8").splitlines(), 1):
        if not raw.strip() or raw.startswith("#"):
            continue
        code, translation = raw.split("|", 1)
        qid = int(code)
        if qid in translations or not translation.strip():
            raise ValueError(f"Invalid Indonesian explanation line {lineno}")
        translations[qid] = translation.strip()
    for chapter, section in CHAPTERS.items():
        file = ROOT / "content" / f"chapter-{chapter}.txt"
        if not file.exists():
            raise SystemExit(f"Missing bank source: {file}")
        current = None
        for lineno, raw in enumerate(file.read_text(encoding="utf-8").splitlines(), 1):
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            parts = [part.strip() for part in line.split("|")]
            if line.startswith("@"):
                if len(parts) != 3:
                    raise ValueError(f"{file}:{lineno}: group needs code, page range, title")
                code = parts[0][1:]
                if (chapter, code) in groups:
                    raise ValueError(f"Duplicate subsection {chapter}.{code}")
                current = (code, parts[1], parts[2])
                groups[(chapter, code)] = 0
                group_meta[(chapter, code)] = (parts[1], parts[2])
                continue
            if current is None or len(parts) not in (10, 11):
                raise ValueError(f"{file}:{lineno}: item needs group and 10/11 fields; got {len(parts)}")
            raw_id, knowledge_unit, kind, difficulty, prompt, correct, w1, w2, w3, explanation = parts[:10]
            image = parts[10] if len(parts) == 11 and parts[10] else None
            qid = int(raw_id)
            if qid // 1000 != chapter:
                raise ValueError(f"{file}:{lineno}: ID {qid} must belong to chapter {chapter}")
            if kind not in ("concept", "scenario", "visual", "calculation", "process"):
                raise ValueError(f"{file}:{lineno}: invalid type")
            if difficulty not in ("basic", "applied", "advanced"):
                raise ValueError(f"{file}:{lineno}: invalid difficulty")
            if any(not value for value in (knowledge_unit, prompt, correct, w1, w2, w3, explanation)):
                raise ValueError(f"{file}:{lineno}: empty required field")
            choices = [correct, w1, w2, w3]
            if len(set(choices)) != 4:
                raise ValueError(f"{file}:{lineno}: duplicate choices")
            seed = int(hashlib.sha256(f"ssw-tg2-{qid}".encode()).hexdigest()[:12], 16)
            rng = random.Random(seed)
            rng.shuffle(choices)
            code, page_range, title = current
            first_page = int(page_range.split("-")[0])
            last_page = int(page_range.split("-")[-1])
            question = {
                "id": qid,
                "section": section,
                "category": title,
                "subcategory": f"{chapter}.{code}",
                "knowledgeUnit": knowledge_unit,
                "question": prompt,
                "choices": choices,
                "correctIndex": choices.index(correct),
                "image": image,
                "source": f"JAIM 特定技能2号 機械金属加工区分 学習用参考テキスト 第2版 p.{page_range}",
                "sourcePages": [first_page, last_page],
                "sourcePdfPages": [first_page + 8, last_page + 8],
                "sourceClass": "AI-generated 予想問題",
                "explanation": explanation,
                "explanationId": translations.get(qid),
                "difficulty": difficulty,
                "questionType": kind,
                "examCategory": "M60-J11J",
            }
            questions.append(question)
            groups[(chapter, code)] += 1
    additions = ROOT / "content" / "additions.txt"
    if additions.exists():
        for lineno, raw in enumerate(additions.read_text(encoding="utf-8").splitlines(), 1):
            if not raw.strip() or raw.startswith("#"):
                continue
            parts = [part.strip() for part in raw.split("|")]
            if len(parts) not in (12, 13):
                raise ValueError(f"{additions}:{lineno}: expected 12/13 fields")
            chapter, code, raw_id, knowledge_unit, kind, difficulty, prompt, correct, w1, w2, w3, explanation = parts[:12]
            chapter, qid = int(chapter), int(raw_id)
            if qid // 1000 != chapter or (chapter, code) not in group_meta:
                raise ValueError(f"{additions}:{lineno}: invalid chapter/subsection/ID")
            if kind not in ("concept", "scenario", "visual", "calculation", "process") or difficulty not in ("basic", "applied", "advanced"):
                raise ValueError(f"{additions}:{lineno}: invalid kind/difficulty")
            choices = [correct, w1, w2, w3]
            if any(not item for item in (knowledge_unit, prompt, explanation, *choices)) or len(set(choices)) != 4:
                raise ValueError(f"{additions}:{lineno}: empty or duplicate content")
            seed = int(hashlib.sha256(f"ssw-tg2-{qid}".encode()).hexdigest()[:12], 16)
            random.Random(seed).shuffle(choices)
            page_range, title = group_meta[(chapter, code)]
            first_page = int(page_range.split("-")[0])
            last_page = int(page_range.split("-")[-1])
            questions.append({
                "id": qid, "section": CHAPTERS[chapter], "category": title,
                "subcategory": f"{chapter}.{code}", "knowledgeUnit": knowledge_unit,
                "question": prompt, "choices": choices, "correctIndex": choices.index(correct),
                "image": parts[12] if len(parts) == 13 and parts[12] else None,
                "source": f"JAIM 特定技能2号 機械金属加工区分 学習用参考テキスト 第2版 p.{page_range}",
                "sourcePages": [first_page, last_page],
                "sourcePdfPages": [first_page + 8, last_page + 8],
                "sourceClass": "AI-generated 予想問題", "explanation": explanation,
                "explanationId": translations.get(qid), "difficulty": difficulty,
                "questionType": kind, "examCategory": "M60-J11J",
            })
            groups[(chapter, code)] += 1
    if set(translations) != {q["id"] for q in questions}:
        raise ValueError("Indonesian explanation IDs do not match the question bank")
    overrides = ROOT / "content" / "option-overrides.txt"
    if overrides.exists():
        by_id = {q["id"]: q for q in questions}
        seen = set()
        for lineno, raw in enumerate(overrides.read_text(encoding="utf-8").splitlines(), 1):
            if not raw.strip() or raw.startswith("#"):
                continue
            parts = [part.strip() for part in raw.split("|")]
            if len(parts) != 5:
                raise ValueError(f"{overrides}:{lineno}: expected ID and four choices")
            qid = int(parts[0])
            if qid not in by_id or qid in seen or any(not item for item in parts[1:]) or len(set(parts[1:])) != 4:
                raise ValueError(f"{overrides}:{lineno}: missing/duplicate ID or choice")
            seen.add(qid)
            choices = parts[1:]
            seed = int(hashlib.sha256(f"ssw-tg2-{qid}".encode()).hexdigest()[:12], 16)
            random.Random(seed).shuffle(choices)
            by_id[qid]["choices"] = choices
            by_id[qid]["correctIndex"] = choices.index(parts[1])
    return questions, groups


def main():
    questions, groups = read_bank()
    ids = [q["id"] for q in questions]
    if len(ids) != len(set(ids)):
        raise SystemExit("Duplicate stable ID")
    missing = {chapter: EXPECTED_SUBSECTIONS[chapter] - sum(1 for c, _ in groups if c == chapter)
               for chapter in CHAPTERS}
    if any(missing.values()):
        raise SystemExit(f"Subsection count mismatch: {missing}")
    if any(not count for count in groups.values()):
        raise SystemExit("Uncovered subsection")
    if any(q["question"].strip() == q["explanation"].strip() for q in questions):
        raise SystemExit("An explanation merely repeats a question")
    questions.sort(key=lambda q: q["id"])
    (ROOT / "questions.json").write_text(json.dumps(questions, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    counts = {str(chapter): sum(q["id"] // 1000 == chapter for q in questions) for chapter in CHAPTERS}
    print(json.dumps({"total": len(questions), "subsections": len(groups), "chapters": counts}, ensure_ascii=False))


if __name__ == "__main__":
    main()

import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { validateQuestions, SECTION_LABELS } from "../core-v2.js";
import { validateFurigana } from "../furigana-v2.js";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const readJson = name => JSON.parse(fs.readFileSync(path.join(root, name), "utf8"));
const questions = readJson("questions.json");
const result = validateQuestions(questions);
const ruby = validateFurigana(questions, readJson("furigana.json"));
readJson("image-furigana.json");
const referenced = new Set(questions.map(q => q.image).filter(Boolean));
const imageDir = path.join(root, "assets", "diagrams");
const files = fs.readdirSync(imageDir).filter(name => name.endsWith(".svg"));
for (const image of referenced) {
  const file = path.join(root, image);
  if (!fs.existsSync(file)) throw new Error("Missing diagram: " + image);
  const svg = fs.readFileSync(file, "utf8");
  if (!svg.includes("<svg") || !svg.includes("</svg>") || svg.length < 300) throw new Error("Invalid SVG: " + image);
}
for (const file of files) {
  if (!referenced.has("assets/diagrams/" + file)) throw new Error("Orphan diagram: " + file);
}
const byChapter = Object.fromEntries(SECTION_LABELS.map((section, i) => [i + 2, questions.filter(q => q.section === section).length]));
const subsections = new Set(questions.map(q => q.subcategory));
const units = new Set(questions.map(q => q.knowledgeUnit));
if (subsections.size !== 99) throw new Error(`Technical subsection coverage changed: ${subsections.size}`);
if (questions.some(q => q.sourcePages[0] < 1 || q.sourcePages[1] > 181 || q.sourcePages[0] > q.sourcePages[1]
  || q.sourcePdfPages[0] !== q.sourcePages[0] + 8 || q.sourcePdfPages[1] !== q.sourcePages[1] + 8)) throw new Error("Invalid textbook page reference");
if (questions.some(q => !["concept", "scenario", "visual", "calculation", "process"].includes(q.questionType)
  || !["basic", "applied", "advanced"].includes(q.difficulty))) throw new Error("Invalid learning metadata");
const normalized = new Set();
for (const q of questions) {
  const key = q.question.replace(/[\s。、！？.,!?]/g, "");
  if (normalized.has(key)) throw new Error("Duplicate question stem: " + q.id);
  normalized.add(key);
}
console.log(JSON.stringify({ ...result, subsections: subsections.size, knowledgeUnits: units.size,
  fourChoices: true, validExplanations: true, diagramsExist: true, orphanDiagrams: 0, byChapter, ruby }));

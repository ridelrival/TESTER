import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import test from "node:test";
import {
  EXAM_LENGTH, EXAM_MINUTES, PASS_PERCENT, SECTION_LABELS, filterQuestions,
  initialState, normalizeState, orderedChoices, progressStats, recordStudyAnswer,
  scoreExam, selectExamQuestions, validateQuestions,
} from "../core-v2.js";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const questions = JSON.parse(fs.readFileSync(path.join(root, "questions.json"), "utf8"));
const byId = new Map(questions.map(q => [q.id, q]));

test("bank covers all mapped technical subchapters with four distinct choices", () => {
  assert.equal(validateQuestions(questions).total, questions.length);
  assert.equal(new Set(questions.map(q => q.subcategory)).size, 99);
  assert.equal(new Set(questions.map(q => q.knowledgeUnit)).size, questions.length);
  assert.ok(questions.every(q => q.choices.length === 4 && q.explanationId));
});

test("choice shuffling preserves the answer identity", () => {
  for (const q of questions) {
    const options = orderedChoices(q, true, 12345);
    assert.equal(options.length, 4);
    assert.equal(new Set(options.map(c => c.originalIndex)).size, 4);
    assert.equal(options.find(c => c.originalIndex === q.correctIndex).text, q.choices[q.correctIndex]);
  }
});

test("study answer and filtered progress survive state normalization", () => {
  const state = initialState();
  const q = questions[0];
  const wrongIndex = (q.correctIndex + 1) % 4;
  assert.equal(recordStudyAnswer(state, q, wrongIndex), true);
  assert.equal(recordStudyAnswer(state, q, q.correctIndex), false);
  const restored = normalizeState(JSON.parse(JSON.stringify(state)));
  assert.equal(restored.progress[q.id].wrongCount, 1);
  assert.equal(filterQuestions(questions, { ...restored, filter: "wrong" }).length, 1);
  assert.equal(recordStudyAnswer(restored, q, q.correctIndex, true), true);
  assert.equal(progressStats(restored, questions).answered, 1);
  assert.equal(restored.progress[q.id].correctCount, 1);
});

test("simulation follows 30 questions, 80 minutes, and 60 percent", () => {
  assert.equal(EXAM_LENGTH, 30);
  assert.equal(EXAM_MINUTES, 80);
  assert.equal(PASS_PERCENT, 60);
  const ids = selectExamQuestions(questions);
  assert.equal(ids.length, EXAM_LENGTH);
  assert.equal(new Set(ids).size, EXAM_LENGTH);
  for (const section of SECTION_LABELS) {
    assert.ok(ids.filter(id => byId.get(id).section === section).length >= 3);
  }
  const passingAnswers = Object.fromEntries(ids.slice(0, 18).map(id => [id, byId.get(id).correctIndex]));
  const passing = scoreExam({ questionIds: ids, answers: passingAnswers }, byId);
  assert.equal(passing.correct, 18);
  assert.equal(passing.passed, true);
  const failing = scoreExam({ questionIds: ids, answers: Object.fromEntries(ids.slice(0, 17).map(id => [id, byId.get(id).correctIndex])) }, byId);
  assert.equal(failing.passed, false);
});

test("recent simulation history rotates questions", () => {
  const first = selectExamQuestions(questions, () => 0.4);
  const second = selectExamQuestions(questions, () => 0.4, [{ questionIds: first }]);
  assert.equal(new Set(second).size, EXAM_LENGTH);
  assert.ok(second.filter(id => first.includes(id)).length < EXAM_LENGTH);
});

# SSW TG2 Manufacturing — 機械金属加工区分

PWA latihan lokal yang diadaptasi dari aplikasi [flashcardsquestionsandanswer](https://ridelrival.github.io/flashcardsquestionsandanswer/). Bank ini berisi **251 soal 予想問題 asli**, bukan soal ujian resmi atau bocoran. Pertanyaan, empat opsi, dan penjelasan teknis tersedia dalam bahasa Jepang; penjelasan belajar juga tersedia dalam bahasa Indonesia.

Versi GitHub Pages: <https://ridelrival.github.io/TESTER/>.

## Menjalankan secara lokal

Prasyarat: Node.js. Proyek tidak memerlukan `npm install` atau layanan eksternal pada saat dijalankan.

```powershell
node scripts/serve.mjs
```

Buka <http://127.0.0.1:4173/ssw-tg2-manufacturing/>. Pembukaan pertama membutuhkan koneksi ke server lokal. Setelah service worker selesai memasang data, halaman dan diagram dapat dibuka tanpa koneksi. Jangan membuka `index.html` sebagai `file://`, karena modul JavaScript, penyimpanan, dan service worker membutuhkan origin HTTP/HTTPS.

## Memeriksa dan membangun

```powershell
node scripts/validate-data.mjs
node --test tests/core.test.mjs
node scripts/build.mjs
```

`dist/` berisi berkas statis siap dipasang pada origin HTTPS dengan direktori aplikasi `/ssw-tg2-manufacturing/`. Folder itu hanya artefak lokal; tidak ada penerbitan otomatis. Bila nama direktori hosting berubah, sesuaikan `manifest.json` dan rute server sesuai kebutuhan. Setelah memperbarui data atau kode, naikkan versi cache di `sw.js` dan versi data cadangan jika skemanya berubah.

## Struktur penting

- `content/chapter-*.txt`, `content/additions.txt`, `content/option-overrides.txt`: sumber soal yang dapat diedit.
- `content/explanations-id.txt`: penjelasan Indonesia menurut ID.
- `scripts/build-questions.py`: membangun `questions.json` dengan pengacakan opsi deterministik.
- `scripts/build-furigana.py`: menghasilkan data furigana dari teks Jepang; membutuhkan `pykakasi==2.3.0` hanya saat regenerasi.
- `scripts/build-diagrams.py`: menghasilkan diagram SVG asli.
- `core-v2.js`, `app-v2.js`, `storage-v2.js`, `furigana-v2.js`: logika belajar, UI, IndexedDB, dan furigana yang diadaptasi dari model PWA rujukan.
- `sw.js`, `manifest.json`: dukungan PWA dan cache offline.
- `questions.json`: bank yang digunakan aplikasi, dengan ID tetap, rujukan halaman, tipe, tingkat kesulitan, dan klasifikasi `AI-generated 予想問題`.

Simulasi menggunakan 30 soal, 80 menit, dan ambang 60% sesuai kerangka resmi yang diverifikasi untuk M60-J11J. Pemilihan soal mencakup setiap bab teknis dan menghindari kombinasi terbaru yang sama, tetapi **bukan** distribusi bobot resmi per topik. Progres tersimpan terpisah dari PWA asal di IndexedDB perangkat ini. Gunakan **Pengaturan → Ekspor progres** untuk membuat cadangan JSON dan **Impor progres** untuk memulihkannya.

Laporan QA akhir dan peta kurikulum tersimpan bersama proyek lokal awal. Bank ini belum mendapat telaah independen oleh pakar untuk seluruh soal; empat kompetensi contoh resmi 2025 masih dicatat sebagai kesenjangan sumber.
